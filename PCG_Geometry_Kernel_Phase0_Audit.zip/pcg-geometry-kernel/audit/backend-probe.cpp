// Dependency readiness probe only. Not a certified interval implementation.
#include <mpfr.h>
#include <gmp.h>
#include <iostream>

int main() {
    mpfr_t x, lo, hi;
    mpfr_inits2(128, x, lo, hi, (mpfr_ptr) nullptr);
    mpfr_set_ui(x, 1, MPFR_RNDN);
    mpfr_sin(lo, x, MPFR_RNDD);
    mpfr_sin(hi, x, MPFR_RNDU);
    const bool ordered = mpfr_number_p(lo) && mpfr_number_p(hi)
        && mpfr_cmp(lo, hi) <= 0;
    std::cout << "MPFR " << mpfr_get_version() << "; GMP " << gmp_version
              << "; directed-rounding linkage smoke: "
              << (ordered ? "PASS" : "FAIL") << '\n';
    mpfr_clears(x, lo, hi, (mpfr_ptr) nullptr);
    return ordered ? 0 : 1;
}
