#!/bin/sh
# Compile into a temporary directory; never change the repository.
set -eu
probe_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
probe_tmp=$(mktemp -d)
trap 'rm -rf "$probe_tmp"' EXIT HUP INT TERM
"${CXX:-c++}" -std=c++20 -Wall -Wextra -Werror \
  "$probe_dir/backend-probe.cpp" -lmpfr -lgmp -o "$probe_tmp/backend-probe"
"$probe_tmp/backend-probe"
