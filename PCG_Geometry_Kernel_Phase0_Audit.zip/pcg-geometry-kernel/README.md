# PCG Geometry Kernel

Status: **Phase 0 audit checkpoint — BLOCKED, not a production kernel.**

This project targets general fixed-turn PCG primitives and certified end-to-end
solvers for selected theorem-supported finite circular-arc trace families.
The immediate scope is Phase 0–3 and the ABCABC vertical slice only.

The supplied Production Charter v5 is preserved byte-for-byte in
`sources/Production_Charter_v5.txt`. Mathematical manuscripts are preserved in
`sources/`; their source and statement digests are in `provenance/`.

There is no implemented solver, certificate verifier, stable API, or release in
this checkpoint. No mathematical decision is claimed by this package.

Read `docs/audit-report.md`, `docs/blockers.md`, and
`docs/superpowers/plans/2026-10-06-abcabc.md` to resume.

Intended GitHub destination: `Duy102/pcg-geometry-kernel`, **public**.
Remote creation and publication have not occurred. No public license is granted.

## Readiness check

On a system with C++20, GMP development files and MPFR development files:

```sh
sh audit/check-backend.sh
```

This is only a dependency/linkage and basic directed-rounding smoke check. It
does not certify a numerical backend or complete any Phase 1–3 acceptance gate.

## Invariants

- REALIZABLE requires verified existence evidence.
- NOT_REALIZABLE requires a verified obstruction.
- Unresolved valid supported input yields INDETERMINATE.
- A theorem-domain violation is a DomainError, not nonexistence.
- Search failure is never a nonexistence proof.

## Immediate exclusions

No Network Closure solver, Seifert solver, ABCADCBD solver, BVH, C/Python bindings,
public API stabilization, GUI, GPU work, or variable-turn solver in Phase 0–3.

