# Computational Benchmarking and Empirical Evaluation of Prime-Curve Geometry (PCG)

## Executive Summary

This report consolidates the computational benchmark program developed across PCG Benchmark Suite v0.1 through v0.10. The goal was not to manufacture a large speedup number, but to determine where Prime-Curve Geometry (PCG) provides a genuine computational advantage, where it does not, and which parts of the current evidence are theorem-level, exact computational certificates, numerical evidence, or still open.

The benchmark campaign supports a clear conclusion:

> **PCG's main computational advantage is structural rather than merely low-level.** It repeatedly transforms a generic geometric search problem into a sequence of smaller, more specialized problems: topological and sign-capacity filters, max-flow, linear or mixed-integer feasibility, positive cycle-space closure, a small residual compatibility equation, and finite exact intersection predicates.

This advantage is strongest when the alternative is a generic nonlinear or coordinate-search formulation. It is smaller when the baseline has already exploited the same linear structure. At the final finite-arc pair-test layer, PCG is often only marginally faster than a well-written complete geometric oracle. Thus the evidence does **not** support the claim that every individual PCG primitive is universally faster than every existing method. It supports the more defensible statement that the **PCG architecture reduces the amount and complexity of geometric search that must be performed**.

The strongest quantitative results include:

- 250,000/250,000 agreement for the exact shared-start `ExtraHit` predicate, with a measured 1.46x speedup over an independently coded generic circle-circle oracle.
- 400/400 agreement for Seifert feasibility across max-flow, LP, and exhaustive cuts; at 20 vertices, max-flow was about 5,222x faster than exhaustive subset-cut enumeration.
- Seifert max-flow used approximately 6x-12x less incremental memory than the LP formulation in the tested sparse graph families.
- The complete fixed-turn `ABCABC` decision agreed with a generic fifteen-pair oracle on 2,000/2,000 cases and ran about 2.18x faster.
- Against Shapely polyline approximation, exact circular predicates were roughly 7x-14x faster in the tested implementations while avoiding discretization error.
- For `ABCADCBD`, PCG was only about 1.22x faster than a strong linear-coordinate baseline, but about 27.5x faster than generic nonlinear coordinate search.
- Network Closure reduced the large planar benchmark formulation to roughly half as many variables and equality constraints as direct coordinates, with solve-time advantages generally becoming more visible as graph size increased.
- In the complete `ABCABC` sign-rotation problem, only 48/192 candidates reached the final `ExtraHit` layer: 75% were rejected earlier by cheaper exact obstruction layers.
- For the `ABCADCBD` 1,024-case sign-rotation frontier, exact early filters reduced 1,024 cases to 592, and a new exact modular positive-triangle MILP reduced them further to 286. Thus 738/1,024 = 72.07% of the raw classes were rejected before the nonlinear K4 compatibility equation.
- The research benchmark program also discovered and audited explicit realizability witnesses, including an exact analytic witness at extreme rotation `r=-3` and its sign-reflected `r=+3` partner, correcting a false numerical conjecture from an earlier benchmark version.
- By v0.10, the eight-arc frontier had the conservative status `1,024 = 738 certified rejects + 40 robust trace-witness classes + 246 unresolved classes`.

The overall conclusion is that PCG should be evaluated as a **theorem-driven reduction architecture for finite curve realizability**, not as a single geometric kernel competing only on raw operation count.

---

## 1. Purpose and Scope

Prime-Curve Geometry is a curve-first framework whose finite circular-realization program asks whether a prescribed trace can be realized by a finite collection of non-full-turn circular pieces satisfying turn, regularity, endpoint, and finite-intersection constraints.

The computational benchmarks focused on the parts of PCG for which the current mathematical development supplies explicit algorithmic structure:

1. exact circular-arc intersection predicates (`Hit` and `ExtraHit`);
2. Seifert turn-flow feasibility;
3. Network Closure and positive cycle-space feasibility;
4. fixed-turn realizability for the six-arc word `ABCABC`;
5. fixed-turn realizability for the eight-arc word `ABCADCBD`;
6. sign-rotation obstruction pipelines;
7. modular chamber decomposition and numerical witness discovery.

The benchmark program deliberately distinguished four evidence levels:

- **Theorem-level statements:** consequences already proved in the PCG manuscripts.
- **Certified computational rejection:** exact finite or optimization conditions whose failure certifies nonexistence within the stated model.
- **Validated numerical witness:** a numerically or analytically constructed realization that passes the PCG criterion and an independent oracle; this proves existence for that instance/class but does not classify all other classes.
- **Unresolved:** failure to find a witness is not treated as proof of impossibility.

This distinction became increasingly important as the benchmark suite evolved from performance measurement into a computational research instrument.

---

## 2. Benchmark Philosophy

The benchmarks were designed around three principles.

### 2.1 Strong baselines rather than deliberately weak competitors

Where possible, PCG was compared not only with brute force, but also with stronger formulations:

- generic circle-circle intersection logic;
- generic linear programming using HiGHS;
- direct-coordinate linear reconstruction;
- generic nonlinear least-squares/root search;
- exhaustive cut enumeration where appropriate;
- polyline-based Shapely geometry;
- full pairwise geometric oracles.

This matters because a large speedup against an unnecessarily weak baseline is not meaningful evidence of a new method's practical value.

### 2.2 Correctness agreement before performance claims

Most benchmark families included an independent cross-check. Examples include:

- PCG `ExtraHit` versus a separately implemented generic circle oracle;
- Seifert max-flow versus LP and exhaustive cuts;
- reduced PCG intersection tests versus full pairwise geometric oracles;
- Network Closure versus direct-coordinate formulations;
- PCG fixed-turn reconstruction versus independent linear or nonlinear coordinate solvers.

### 2.3 Report negative or neutral results

Several benchmark versions intentionally preserved results where PCG did not dominate. For example:

- the isolated 18-predicate final pair layer of `ABCADCBD` was approximately equal in runtime to the full 28-pair oracle in pure Python;
- direct-coordinate sparse LP could outperform PCG on some Network Closure instances and sizes;
- large-instance HiGHS runtime varied substantially across numerical instances;
- early numerical evidence suggesting that `r=±3` forced intersections was later falsified.

These outcomes are scientifically useful because they locate the actual source of PCG's advantage.

---

## 3. Exact Circular-Arc Predicate Benchmarks

### 3.1 Shared-start `ExtraHit`

The first benchmark isolated the exact `ExtraHit` formula used when two circular arcs share a prescribed endpoint and one must determine whether their supporting circles create an additional finite-arc intersection.

Across 250,000 nondegenerate random cases, the PCG predicate and an independently coded generic circle-circle oracle had:

- **0 disagreements**.

On 1.5 million cases, the vectorized benchmark measured approximately:

- **1.46x speedup** for the specialized PCG formula.

This is a modest constant-factor improvement, but it has two important properties: the predicate is exact within the model, and it avoids unnecessary generic geometric work.

### 3.2 Exact arcs versus polyline approximation

In later suites, circular arcs were compared with Shapely polyline approximations.

For the six-arc shared-start test, the polyline approximation agreement improved from approximately 97.6% at 16 segments per arc to 99.8% at 256 segments per arc, while the exact PCG scalar predicate remained exact on the tested nondegenerate cases and was approximately 10.6x-13.9x faster in that implementation.

For the eight-arc benchmark, the corresponding Shapely/PCG median speed ratios were approximately 7x-9x depending on segmentation density.

The main conclusion is not that Shapely is intrinsically slow. The important difference is representational: a generic polyline method must approximate a circular primitive by many segments, while PCG operates directly on the circular geometry.

---

## 4. Seifert Turn-Flow Benchmarks

The Seifert layer converts local turn-capacity consistency into a flow problem on the Seifert graph.

### 4.1 Correctness

In the first randomized audit:

- **400/400** instances agreed among PCG max-flow, maximum-common-slack LP, and exhaustive cut checking.

In the later complete `ABCADCBD` sign-rotation enumeration:

- explicit cut inequalities and an independent LP agreed on **1,024/1,024** cases.

### 4.2 Runtime

On larger graph instances, PCG max-flow remained more than 2x faster than the generic LP over the tested 16-512 vertex range.

Against exhaustive subset-cut enumeration, the asymptotic distinction became dramatic. At 20 vertices, the measured ratio was approximately:

- **5,222x** in favor of max-flow.

This benchmark is particularly meaningful because the mathematical reduction replaces an exponentially large family of cut checks by one polynomial-time flow computation.

### 4.3 Memory

The Seifert memory benchmark found substantially lower incremental memory use for the max-flow formulation than for the LP formulation. Depending on instance family and rerun protocol, the measured reduction was roughly:

- **6x-12x less incremental peak memory**.

The precise factor is implementation- and solver-dependent, but the qualitative result is consistent with the smaller specialized representation.

### 4.4 Interpretation

The Seifert results illustrate one of the central computational patterns of PCG:

> replace a large family of constraints or a generic optimization formulation by a graph problem with a specialized polynomial-time algorithm.

The very large speedup against exhaustive cuts should not be extrapolated to every PCG workload, but the complexity-class improvement is genuine.

---

## 5. Network Closure and Scaling

Network Closure expresses global endpoint consistency through a positive cycle-space condition

\[
N(G,\alpha)c=0,\qquad c>0,
\]

rather than retaining every vertex coordinate as a primary unknown.

### 5.1 Structural compression

In the large planar scaling benchmark, PCG used approximately half as many variables and equality constraints as the direct-coordinate LP formulation.

At 3,072 vertices, the reported model sizes were approximately:

- PCG: 6,145 variables and 6,147 equality constraints;
- direct coordinates: 12,287 variables and 12,289 equality constraints.

This near-50% reduction is one of the most stable conclusions of the entire benchmark campaign because it follows from representation rather than a particular solver timing.

### 5.2 Facial cycle basis

Because Network Closure is invariant under the choice of cycle basis, planar graphs allow the use of a sparse facial cycle basis instead of a generic spanning-tree fundamental basis.

At 3,072 vertices, the facial representation had substantially fewer nonzeros than the fundamental-cycle representation. This demonstrates that the theorem permits an additional implementation-level optimization that respects the planar structure of PCG quotient networks.

### 5.3 Runtime scaling

Across three independent benchmark batches, all formulations agreed on **186/186** tested linear cases.

For exact feasible instances, pooled median direct-coordinate/PCG solve ratios increased from roughly 1.1x at very small sizes to multi-fold advantages at larger sizes. Representative results include:

- 192 vertices: about **2.25x**;
- 384 vertices: about **2.89x**;
- 768 vertices: about **3.02x**;
- 3,072 vertices: pooled median about **3.65x**, with substantial batch-to-batch variation.

The large-instance timing was not monotone and depended on the numerical behavior of HiGHS. Therefore the model-size reduction is a stronger and more portable conclusion than any single speedup number.

### 5.4 Comparison with generic nonlinear coordinate search

The advantage becomes much larger when the alternative is a generic nonlinear coordinate formulation. At 48 vertices, one tested median ratio was about:

- **97.4x** in favor of PCG.

At larger small-to-medium cases, even larger ratios were observed, but with greater variability. These results should be interpreted as evidence that **eliminating coordinate search** is valuable, not as a universal 100x PCG speed claim.

---

## 6. Complete Six-Arc `ABCABC` Evaluation

The six-arc family is the cleanest fully classified PCG benchmark because the theorem-level sign-rotation classification is complete.

### 6.1 Fixed-turn end-to-end decision

On 2,000 phase-consistent, metric-feasible turn vectors, including 107 trace-rejected cases:

- PCG and the independent fifteen-pair circle oracle agreed on **2,000/2,000** cases;
- median cost was about 0.0588 ms per case for PCG versus 0.1282 ms for the full oracle;
- measured speedup: **2.18x**.

### 6.2 Complete sign-rotation classification

The theorem-level classifier covers all 192 candidate pairs and identifies exactly 36 minimal realizable cases. Because the classification has been compiled into a finite rule, the online classifier can execute extremely quickly; one pure-Python microbenchmark measured approximately 12.78 million decisions per second.

This number should not be compared directly with a solver that is solving a fresh continuous problem: it measures the cost after mathematical classification has already been completed.

### 6.3 Obstruction economics

The v0.5 pipeline recomputed the complete obstruction funnel:

\[
192 \rightarrow 146 \rightarrow 110 \rightarrow 48 \rightarrow 36,
\]

with stage losses corresponding to Seifert, phase, positive closure, and forced `ExtraHit` effects.

The key computational observation is:

- only **48/192 = 25%** of candidates reach the final intersection layer;
- **75%** are removed before the expensive Euclidean `ExtraHit` stage.

Removing the Seifert preprocessor increased the median full-pipeline runtime from approximately 3.391 s to 4.010 s, so Seifert saved about 15.4% wall time and about 18% of LP calls on this already small complete problem.

A more direct metric-search ablation required 24,481 LP calls compared with 3,771 in the staged PCG pipeline, approximately **6.49x** more solver calls. Its single-run runtime was approximately **6.04x** larger.

The six-arc family therefore demonstrates that the value of PCG lies not only in the final predicate, but in **ordering cheap exact obstructions before expensive geometry**.

---

## 7. Eight-Arc `ABCADCBD`: Fixed-Turn Benchmarks

The eight-arc word is significantly more demanding. Its complete pair structure contains 28 arc pairs, but the PCG theorem decomposes these into structural and geometric categories, leaving 12 local `ExtraHit` and 6 remote `Hit` predicates after metric reconstruction.

### 7.1 Correctness

The benchmark suites reported:

- 500/500 agreement between the PCG reduced pair layer and a generic full geometric classification;
- 300/300 agreement against a strong direct-coordinate linear baseline;
- 60/60 agreement against generic nonlinear coordinate search.

### 7.2 Performance against strong and weak baselines

Against the strong linear-coordinate baseline, the median end-to-end speedup over seven reruns was only:

- **1.219x**.

Against generic nonlinear coordinate search, the median speedup was:

- **27.49x**.

This contrast is one of the most important results in the benchmark program. Once the baseline already exploits the same linear structure, PCG's constant-factor advantage is modest. When the baseline performs generic nonlinear geometric search, theorem-driven reconstruction produces a much larger advantage.

### 7.3 Final pair layer

The isolated reduced 18-predicate PCG pair layer was approximately equal in runtime to the generic 28-pair oracle in pure Python. Later testing similarly found only about a 1.03x difference.

Therefore:

> The final intersection layer is not the main source of PCG's computational advantage.

The advantage appears earlier, in the reduction and reconstruction stages.

---

## 8. Eight-Arc Sign-Rotation Frontier

The `ABCADCBD` sign-rotation problem contains:

\[
256\times 4=1024
\]

raw classes for rotations `r in {-3,-1,1,3}`.

The complete 1,024-case classification is not yet a theorem. The benchmark campaign therefore treated this as an open research frontier.

### 8.1 Exact early filters

v0.6 established the exact computational funnel:

\[
1024\rightarrow820\rightarrow712\rightarrow592.
\]

The stages were:

- global sign-count: 204 rejected;
- Seifert feasibility: 108 additional rejected;
- two phase equations: 120 additional rejected.

Thus 432/1,024 = **42.19%** of the raw space was removed before nonlinear K4 analysis.

The Seifert and phase filters were shown to be genuinely independent: among the 820 global-count survivors, some passed phase but failed Seifert, while others passed Seifert but failed phase.

### 8.2 Exact modular positive-triangle filter

v0.8 introduced an important new exact reduction. The sign condition on each sine term can be represented by linear inequalities modulo integer half-turn cells. Therefore the three positive-triangle requirements can be compiled into a finite MILP rather than handled only by nonlinear trigonometric search.

This reduced:

\[
592\rightarrow286.
\]

Therefore the total exact rejection count became:

\[
738/1024=72.07\%.
\]

This is one of the strongest structural results of the benchmark campaign: nearly three quarters of the raw sign-rotation space can be rejected before solving the remaining nonlinear K4 compatibility equation.

### 8.3 Numerical metric and trace witnesses

The numerical search program progressively increased the lower bound on known realizable classes while carefully avoiding the false inference that “no witness found” means “impossible.”

v0.7 produced 118 robust metric-witness classes. v0.8 increased the metric lower bound and corrected the trace-witness accounting from the earlier release. v0.9 then made an especially important correction: the tentative conjecture that extreme rotations `r=±3` might always force an unintended intersection was false.

An explicit exact witness was found for:

- `r=-3`, sign pattern `--------`,

with turn vector

\[
\left(-\frac14,-\frac38,-\frac14,-\frac58,-\frac14,-\frac38,-\frac14,-\frac58\right),
\]

and a sign-reflected partner for `r=+3`.

The K4 compatibility identity simplifies exactly, and the chord lengths are expressible in radicals. A dense within-class test found 406 trace-faithful roots among 600 tested K4 roots for the all-negative `r=-3` class, demonstrating that a single bad metric representative cannot classify an entire sign-rotation class.

### 8.4 Chamber atlas and v0.10 frontier

v0.10 refined the computational unit further:

\[
\text{sign-rotation class}
\to
\text{phase branch}
\to
\text{modular triangle chamber}
\to
\text{K4 sheet}
\to
\text{Hit/ExtraHit region}.
\]

Across the 266 classes unresolved after v0.9, the declared search observed:

- 491 distinct phase/triangle chambers;
- 205 chambers with sampled K4 sign changes;
- 2,411 valid K4 roots;
- 17 chambers containing a trace-faithful root.

After exact sign reflection, 20 new sign-rotation classes were added to the trace-witness lower bound.

The conservative v0.10 status is therefore:

\[
\boxed{1024=738+40+246}
\]

where:

- 738 classes are certified rejects before nonlinear K4 compatibility;
- 40 classes have robust trace-faithful witnesses;
- 246 classes remain unresolved.

All 20 new v0.10 witnesses passed both the reduced PCG criterion and the independent full 28-pair oracle.

---

## 9. What the Benchmarks Say About PCG

### 9.1 PCG is primarily a reduction architecture

The strongest recurring pattern is not “a PCG formula is always faster than a generic formula.” It is:

\[
\text{generic geometric search}
\longrightarrow
\text{structured decision pipeline}.
\]

PCG repeatedly removes degrees of freedom before expensive geometry is attempted:

- topology and sign constraints remove impossible inputs;
- Seifert turns local balance into flow;
- phase conditions convert periodic geometry into discrete-linear branches;
- Network Closure removes redundant vertex coordinates;
- planar facial cycles sparsify the closure system;
- modular sine-sign constraints become MILP cells;
- only a reduced compatibility problem remains nonlinear;
- final trace-faithfulness becomes a finite list of exact pair predicates.

This is a stronger and more general computational principle than a fixed speedup factor.

### 9.2 PCG is most advantageous when the baseline is generic

The benchmark data show a consistent hierarchy:

- versus exhaustive combinatorial search: potentially orders-of-magnitude improvement;
- versus generic nonlinear coordinate search: often tens to hundreds of times faster in tested families;
- versus generic discretized geometry: substantial speedups plus exactness advantages;
- versus a strong linear formulation that already exploits the same structure: usually modest constant-factor gains;
- at the final pair-test layer alone: often near parity.

Therefore the correct claim is not universal superiority of every PCG operation. It is that **PCG exposes mathematical structure that generic methods may fail to exploit automatically**.

### 9.3 Exact representation is an important practical advantage

Polyline methods trade accuracy for cost. PCG retains exact circular primitives and exact finite-arc predicates. This matters near decision boundaries and when discretization would require many segments.

The near-degeneracy tests also showed agreement between float64 and high-precision evaluation down to approximately `1e-16` perturbations in the tested families, although exact degeneracies remain outside the generic theorem assumptions.

### 9.4 Structural compression is more robust than raw timing

Runtime depends on language, solver, sparsity ordering, hardware, and numerical conditioning. Model size is more portable.

Network Closure's near-halving of variables and equality constraints, the replacement of exponentially many cuts by max-flow, and the removal of 72% of the eight-arc sign-rotation space before K4 are therefore stronger conclusions than any single runtime ratio.

### 9.5 The benchmark suite has become a theorem-discovery instrument

The later versions did more than measure speed. They:

- discovered an exact modular positive-triangle MILP layer;
- identified independent obstruction layers;
- exposed the need to classify entire metric manifolds rather than one representative;
- falsified the tentative `r=±3` unavoidable-hit conjecture;
- produced an explicit analytic extreme-rotation witness;
- motivated a chamber-based architecture for the remaining classification problem.

This is important evidence that PCG's layered formulation is useful not only computationally but also as a research methodology.

---

## 10. Claims Supported by the Current Evidence

The benchmark campaign supports the following statements.

### Strongly supported

1. **PCG can reduce the dimensionality and constraint count of finite curve-realization problems.**
2. **Seifert preprocessing can reject impossible instances before metric solving and can be implemented with specialized flow algorithms.**
3. **Network Closure can replace direct coordinate unknowns by a smaller positive cycle-space system.**
4. **Exact circular predicates can avoid the discretization cost and approximation error of polyline geometry.**
5. **Layered obstruction pipelines can eliminate a large fraction of candidate sign-rotation classes before expensive nonlinear geometry.**
6. **For the tested families, PCG's largest speedups occur against generic nonlinear or exhaustive search, while gains against strong structure-aware linear baselines are smaller.**
7. **The benchmarked PCG criteria have repeatedly agreed with independent geometric or optimization oracles on the tested instances.**

### Not supported as universal claims

The current evidence does **not** justify saying that:

- PCG is always faster than every existing geometric method;
- every PCG kernel has a large constant-factor speed advantage;
- the measured Python/HiGHS speedups will transfer unchanged to C++, GPU, CAD, GIS, or industrial geometry engines;
- the `ABCADCBD` 1,024-case sign-rotation classification is complete;
- failure to find a numerical witness proves nonexistence;
- the current computational results establish historical novelty over the entire computational-geometry literature.

---

## 11. Recommended Publication Positioning

A defensible paper-level computational claim would be:

> **Prime-Curve Geometry provides theorem-driven structural reductions for finite circular-arc realization problems. Across representative six-arc, eight-arc, Seifert-flow, and network-closure benchmarks, these reductions decrease search dimension, eliminate large portions of the candidate space before nonlinear geometry, preserve exact circular primitives, and yield measured performance advantages ranging from modest constant factors against structure-aware linear baselines to orders of magnitude against exhaustive or generic nonlinear formulations.**

This statement is stronger scientifically than “PCG is X times faster,” because it identifies the mechanism of the advantage and remains true even when a particular solver timing fluctuates.

---

## 12. What Is Still Needed for a Publication-Grade Superiority Study

The existing suite is already suitable as a serious internal computational evaluation and as the basis for a paper section, but a stronger external claim should add:

1. a compiled implementation in C++/Rust/Julia to separate mathematical advantage from Python overhead;
2. standardized benchmarking hardware and pinned software versions;
3. larger numbers of independent seeds at the largest Network Closure sizes;
4. comparisons with established computational-geometry libraries such as CGAL or Boost.Geometry where equivalent operations exist;
5. comparisons with symbolic/semialgebraic tools such as SMT, CAD, or interval-certified solvers for the variable-turn problem;
6. external reproduction by an independent implementation;
7. real or application-derived trace networks rather than only synthetic benchmark families;
8. explicit memory, preprocessing, solver, and end-to-end accounting under one benchmark protocol;
9. exact certificates for more of the remaining 246 `ABCADCBD` classes;
10. a final separation between algorithmic novelty, mathematical novelty, and engineering optimization.

---

## 13. Final Conclusion

The benchmark campaign from v0.1 through v0.10 changes the most reasonable interpretation of PCG.

PCG should not be presented primarily as a faster circle-intersection routine. Its computational value lies deeper:

\[
\boxed{
\text{PCG converts geometric search into structured, progressively cheaper certificates.}
}
\]

The empirical evidence shows four recurring benefits:

1. **early rejection** — impossible cases are removed before expensive geometry;
2. **representation compression** — unnecessary coordinate variables and constraints are eliminated;
3. **specialized algorithms** — generic feasibility is replaced by flow, sparse linear systems, finite MILPs, or exact predicates when theorems permit;
4. **exact primitive preservation** — circular geometry can be handled directly instead of by discretization.

The strongest benchmark results appear when these reductions eliminate generic search altogether. The weakest results appear when the comparison method has already discovered essentially the same mathematical structure. This is exactly what one would expect from a theory whose main contribution is structural organization rather than a single low-level numerical trick.

Accordingly, the present evidence supports the conclusion that **PCG is a promising theorem-driven computational framework for finite circular-curve realizability, with demonstrated structural and computational advantages on its current canonical benchmark families**. The evidence is not yet sufficient for a universal claim of superiority over all existing computational geometry methods, and the eight-arc sign-rotation classification remains incomplete. However, the benchmark series has already shown that the PCG architecture can simultaneously improve computation, expose exact obstruction layers, produce verifiable witnesses, and guide the next mathematical questions.

That combination—**proof structure, algorithmic reduction, exact geometry, and computational falsifiability**—is presently the strongest case for PCG.

---

## Source Basis

This synthesis is based on the benchmark reports and data from PCG Benchmark Suite v0.1 through v0.10, together with the current PCG monograph and the fixed-turn / Seifert / Network Closure manuscripts used to define the benchmarked decision rules. Benchmark measurements are empirical results of the released implementations; theorem statements remain logically distinct from those measurements.
