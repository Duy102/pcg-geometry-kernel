# Trusted computing base — intended boundary, not validated

The intended verifier depends on:

1. C++ compiler/runtime and defined-behavior implementation (no fast-math).
2. GMP integer/rational arithmetic and bounded exact input parser.
3. MPFR correctly rounded primitives, plus our interval propagation, extrema,
   argument-reduction and sinc remainder logic.
4. Canonical serialization and SHA-256 implementation (OpenSSL EVP interface).
5. The trusted theorem registry and its reviewed source statements.
6. Finite-arc membership, explicit contact classification and reconstruction
   logic actually used by certificate verification.

Candidate search, generic optimizers, benchmark timing, visualization and
research modules are not authoritative verification dependencies. The verifier
must not call the solver to obtain the answer it purports to check.

Production and reference implementations may share GMP/MPFR. Differential tests
then check geometric/algorithmic independence above that substrate; they do not
independently validate the numeric TCB. Test arithmetic separately with analytic
cases, directed-rounding bounds, exact identities and independent reference data.

Proposed dependency direction: pcg-kernel → pcg-core; pcg-reference → pcg-core;
pcg-research may use kernel/core. Kernel must never depend on research/reference.
None of these product targets exists yet at this blocked audit checkpoint.

