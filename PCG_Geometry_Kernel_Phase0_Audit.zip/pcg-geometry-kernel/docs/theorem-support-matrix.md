# Theorem support matrix

Registration does not mean implementation or a formal proof audit.

| ID | Statement | Immediate role | Status |
|---|---|---|---|
| PCG-CORE-DEF-001 | Primitive PCG datum | core definition | NOT_IMPLEMENTED |
| PCG-ABCABC-THM-001 | Complete constrained six-arc realizability criterion | Phase 3 target | DOMAIN_FREEZE_BLOCKED |
| PCG-ARC-LEM-001 | Finite-arc membership | Phase 2 generic reference membership | NOT_IMPLEMENTED |
| PCG-EXTRAHIT-LEM-001 | Second supporting-circle intersection | Phase 2 production predicate | NOT_IMPLEMENTED |
| PCG-EXTRAHIT-LEM-002 | Exact shared-start interior criterion | Phase 2 production predicate | DOMAIN_FREEZE_BLOCKED |
| PCG-ABCABC-CLASS-001 | Complete six-arc \(ABCABC\) sign--rotation classification | witness provenance only; classification outside immediate solver scope | NOT_IMPLEMENTED |
| PCG-NC-THM-001 | PCG Network Closure Theorem | future Phase 5 only | NOT_IMPLEMENTED |
| PCG-SEIFERT-THM-001 | Seifert-flow max-flow/min-cut theorem | future Phase 6 relaxed flow only | NOT_IMPLEMENTED |
| PCG-ABCADCBD-THM-001 | Complete fixed-turn \(ABCADCBD\) criterion | future Phase 7 only | NOT_IMPLEMENTED |
| PCG-REFINEMENT-CLAIM-001 | Sharp PCG refinement formula | M01 | QUARANTINED_PENDING_RECONCILIATION |
| PCG-REFINEMENT-COND-001 | Conditional sharp refinement theorem | M01 | QUARANTINED_PENDING_RECONCILIATION |
| PCG-REFINEMENT-CONJ-001 | Sharp PCG refinement formula | M01; conjecture is never production authority | QUARANTINED_PENDING_RECONCILIATION |

All other supplied sources are inventoried and retained, but no additional production capability is claimed. Older Core/Post-Flow/Seifert versions remain historical references; exact adoption is always bound to a digest.
