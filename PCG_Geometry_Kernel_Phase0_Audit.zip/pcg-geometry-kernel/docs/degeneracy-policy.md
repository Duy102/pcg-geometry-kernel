# Degeneracy policy — proposed, freeze blocked by M02

| Case | Generic geometry target | ABCABC theorem path |
|---|---|---|
| tau=0 | Separate straight-segment case, outside immediate arc type | DomainError |
| \|tau\|=2pi or larger | Outside finite non-full-turn arc contract | DomainError |
| zero chord | Degenerate representation/domain validation | DomainError |
| prescribed source tangency | Supported with explicit contact identity | Allowed by C1 source passage |
| nontransverse prescribed crossing | Representable relation | DomainError |
| unintended tangency | Structured contact result | DomainError if excluded by theorem genericity |
| coincident supports | Explicit COINCIDENT relation and overlap semantics | DomainError where distinctness is required |
| close but provably distinct centers | Escalate precision as needed | Supported if other preconditions hold |
| unresolved separation or membership | UNKNOWN relation | INDETERMINATE, not DomainError inferred from uncertainty |
| endpoint/interior or multiple-contact boundary | Explicit endpoint and interior classifications | Must resolve genericity scope before freeze |
| singular reconstruction | Report singularity, not optimizer failure as proof | DomainError where it violates a precondition |
| semicircle | Separate half-plane membership rule | Do not silently exclude: source witnesses contain semicircles; M02 open |

The vertical-slice theorem says 'supporting circles that are required to be
distinct', not necessarily every pair. Enumerate and justify exactly which
pair classes need distinctness. Requiring all 15 distinct would narrow the
supported domain and must not be passed off as the original theorem's domain.

SupportingCircle and CircularArc are separate types. A finite arc retains
endpoints, orientation, signed turn, support, radius, finite angular locus and
tangent data. Circle intersection alone is never finite-arc intersection.

