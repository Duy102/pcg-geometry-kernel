# ADR-001: C++20 for the initial certified native kernel

Decision date: 2026-10-06 (user timezone). Status: SELECTED; backend validation blocked.

| Option | Main benefit | Main cost |
|---|---|---|
| C++20 | Direct documented GMP/MPFR C interfaces, RAII wrappers, native geometry types | Memory/undefined-behavior risks; require sanitizers and strict warnings |
| Rust | Ownership and memory safety help constrain implementation defects | GMP/MPFR FFI and wrapper/dependency choices still require an audited native boundary |

Choose C++20 with explicit typed Angle/Turn, RAII MPFR/GMP ownership, no implicit
angle/unit conversions and no global mutable precision. Tier 1: Ubuntu 24.04
x86-64, GCC 13. Build with CMake once available. Use the documented headers;
do not reproduce library ABI layouts manually to work around missing packages.

The current compiler exists (GCC 13.3.0), but CMake and the GMP/MPFR development
headers are unavailable. This is an environment blocker, not evidence against
the chosen language. No Python product implementation, C ABI or bindings in
the immediate build. An audit packaging script is not part of the kernel.

