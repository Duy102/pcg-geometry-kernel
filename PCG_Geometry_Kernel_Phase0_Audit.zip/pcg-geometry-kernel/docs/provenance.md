# Provenance

`provenance/sources.json` binds every supplied manuscript and the build charter
to the SHA-256 of its exact bytes. Source names are preserved where possible;
the scratch numeric prefixes are removed. Original filenames and versions are
recorded separately, so filename changes cannot masquerade as content changes.

`provenance/theorems.json` assigns stable IDs to selected statements and records
source document, source version, source digest, exact statement-byte digest and
source location. Statement digest covers the complete TeX environment from
begin through end, not its proof. An ID identifies a statement lineage, not an
endorsement, formal proof check, implemented capability, or complete source audit.

All registered capabilities are currently NOT_IMPLEMENTED. Conflicting global
refinement claims are QUARANTINED_PENDING_RECONCILIATION. No certificate should
cite them as an unconditional production guarantee. The latest-looking filename
does not silently settle a mathematical conflict.

Benchmark report counts and speedups are historical, unrerun evidence. The
benchmark implementation, seeds and raw data were not among the supplied
files. Do not describe those numbers as tests performed in this checkpoint.
The unrelated GCNT manuscript is inventory-only and has no PCG authority.

For future certificates use pcg-abcabc-certificate schema 1.0; include canonical
input digest and policy version, theorem/source digests, kernel/backend versions,
proof kind, arithmetic assurance, precision and proof-relevant witnesses/bounds.
Keep engineering execution trace outside the certificate. Reject unknown future
schema versions. A verifier must derive its own decision and check all provenance
against a trusted registry, rather than trusting hashes supplied by a certificate.

