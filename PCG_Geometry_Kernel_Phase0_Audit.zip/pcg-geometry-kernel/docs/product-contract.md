# Product contract — Phase 0 draft

Normative input: Production Charter v5. Contract freeze is not complete while
the blockers in `blockers.md` remain open.

Only complete supported theorem solvers may report REALIZABLE or NOT_REALIZABLE.
Each such report must carry a non-NONE ProofKind and arithmetic assurance EXACT
or CERTIFIED_NUMERICAL. An independent verifier must derive the decision from
evidence, not accept the solver's stored status. Unresolved supported instances
are INDETERMINATE, with a separate TerminationReason. Mathematically valid but
unimplemented problem classes are UNSUPPORTED.

## Four distinct layers

| Layer | Meaning | Examples |
|---|---|---|
| InputError | Malformed representation | InvalidSchema, WrongFieldType, NonFiniteInput, UnsupportedSchemaVersion, CorruptCertificate |
| DomainError | Selected theorem's assumptions fail | ZeroTurnOutsideTheoremDomain, FullTurnOutsideTheoremDomain, RequiredNondegeneracyViolated, WrongTraceFamily |
| Decision | Supported mathematical conclusion | REALIZABLE, NOT_REALIZABLE, INDETERMINATE, UNSUPPORTED |
| TerminationReason | Execution outcome | COMPLETED, PRECISION_LIMIT, TIME_LIMIT, MEMORY_LIMIT, SOLVER_LIMIT, USER_CANCELLED, BACKEND_FAILURE |

ProofKind: THEOREM_INSTANTIATION, CONSTRUCTIVE_WITNESS, DUAL_OBSTRUCTION,
FINITE_PREDICATE_CERTIFICATE, FLOW_CERTIFICATE, POSITIVE_KERNEL_CERTIFICATE,
COMPOSITE_CERTIFICATE, NONE. ArithmeticAssurance is a separate axis: EXACT,
CERTIFIED_NUMERICAL, NONE. UNCERTIFIED_NUMERICAL is research-only.

## ABCABC assumptions and decisions

Source order is e1:A→B, e2:B→C, e3:C→A, e4:A→B, e5:B→C, e6:C→A.
The fixed-turn theorem assumes C1 source passage, 0<|tau_i|<2pi, transverse
prescribed crossings, required distinct supports, and its stated genericity
conditions. Preserve the complete statement identified by PCG-ABCABC-THM-001.
Its exact interpretation of 'antipodal' must be resolved in blocker M02.

Pipeline: parse → syntactic validation → theorem-domain validation →
canonicalization → certified theorem predicates → certificate → verification.
Derived geometric assumptions are checked as soon as the skeleton is available,
before using reductions that require them. Missing/uncertain assumptions cannot
be converted into either theorem conclusion.

The three phase congruences, common nonzero sine sign for triangle closure, and
six ExtraHit exclusions are separate obligations. All 15 unordered pairs are
accounted for: 3 paired-endpoint, 6 source-adjacent tangent, 6 cross-passage.
The complete 15-pair reference oracle must be independent of this reduction.

Explicit `solve_abcabc` on a different valid trace raises WrongTraceFamily.
A future general dispatcher returns UNSUPPORTED for an unimplemented valid
family. This distinction is an interface choice, not a theorem assertion.

Future intermediate modules use only CLOSURE_* or SEIFERT_* stage statuses.
Neither proves complete trace realizability by itself.

