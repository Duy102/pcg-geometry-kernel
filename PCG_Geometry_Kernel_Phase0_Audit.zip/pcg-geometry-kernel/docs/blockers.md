# Blocker register

## E01 — certified build backend unavailable (OPEN, environment)

The workspace has GCC 13.3.0 and GMP/MPFR runtime shared libraries, but no usable
public development headers/link targets or CMake. `apt-get install -y
libmpfr-dev libgmp-dev cmake` returned exit 100: packages could not be located.
`apt-get update` returned exit 100 with setgroups/setegid/seteuid permission
errors. Do not bypass the environment's controls or hand-declare native ABI.

Release condition: provide a permitted build environment with documented GMP
and MPFR development packages; record versions; pass the backend probe and
the full numerical TCB tests. The probe alone is insufficient.

Charter consequence: rigorous transcendental evaluation is not executable or
validated here. Stop before Phase 1; Phase 0 DoD is not fully met.

## M01 — global refinement source status discrepancy (OPEN, quarantined)

PCG_Refinement_Complexity_v0.2, theorem labelled thm:global, states the universal
rho_PCG(W)=2n+s(W) formula unconditionally. Its loopless-core theorem applies a
near-Lombardi construction to all loopless plane-realizable words.

PCG_Fully_Reduced_Core_Theorem states a conditional global result assuming the
isolated-chord insertion lemma. PCG_Monograph_v1.3_Appendix_C, conjecture
conj:main-pcg and the final chapter perspective, calls the universal formula
a conjecture and leaves universal reconstruction interfaces open.

This is an unresolved status/model discrepancy, not a demonstrated mathematical
counterexample: the sources' atom models and host hypotheses must be compared.
Do not silently choose the strongest statement or overwrite a manuscript.
Quarantine general sharp-refinement production claims. No claim is made that
this discrepancy falsifies the separate fixed-turn ABCABC theorem.

Release condition: an explicit scoped authority note reconciles definitions,
proof dependencies and supersession, with reviewed source digests. General
refinement is outside Phase 0–3; it must remain outside the ABCABC dependency
closure if work resumes without a general resolution.

## M02 — precise executable ABCABC genericity contract (OPEN, mathematical scope)

The v0.3 theorem excludes 'antipodal or tangent degeneracy' except prescribed
source tangencies and asks for supporting circles 'required to be distinct'.
The v0.4 positive witness contains tau=pi semicircles. This is not necessarily
a contradiction: 'antipodal' may concern a candidate argument branch, rather
than semicircular endpoints. The source does not make that interpretation
executable in the theorem statement alone.

Release condition: document which vectors/events are antipodal, the exact
support pairs requiring distinctness, and endpoint/interior contact semantics;
derive the checks from the source proofs and generic arc membership lemma.
Confirm the intended theorem domain without silently narrowing or enlarging it.
Until then do not freeze the ABCABC contract or report a complete solver.

## G01 — public GitHub repo creation capability absent (OPEN, delivery)

Authenticated account: Duy102. The accessible repository list and scoped PCG
repository search returned no PCG repository. This is not a claim about repos
outside the connector's access. The available GitHub plugin can read/write
repository content but exposes no create-repository or visibility-update action.
GitHub CLI is not installed. Nothing has been published or made public.

Release condition: use an authorized supported route to create
Duy102/pcg-geometry-kernel with public visibility, or have the user create that
empty public repository. Browser fallback requires user approval under the
browser tool instructions. Verify visibility before uploading any source.

