# Canonicalization policy pcg-fixed-turn-v1 — proposed

Angles are in radians; lengths have caller-owned homogeneous units. No silent
unit conversion. Preserve signed turns and total rotation; do not reduce turns
modulo 2pi. Only direction comparisons may use phase congruence.

For a named ABCABC input preserve source order and orientation, map the first
three distinct labels to A,B,C, and retain the inverse label mapping. No cyclic
shift, reflection or orientation reversal is silently applied in v1.

Set phi1=0 and A=(0,0). Normalize the sum of ALL SIX chord magnitudes to 1.
With c4=c1,c5=c2,c6=c3 this means primary chord sum=1/2, not 1.
These normalizations remove only rigid motion and common positive scale.
CanonicalFrame retains origin, initial rotation and positive scale for a user
frame when the caller supplied one; otherwise explicitly mark it unspecified.
Inverse transformation: user_point=origin+scale*R(rotation)*canonical_point.

Canonical input bytes: versioned schema, explicit type tag for each numeric
representation, fixed field order, UTF-8, normalized reduced rationals with
positive denominator and exact integer strings, fixed source order. Bound
endpoints use exact dyadic mantissa/exponent strings, never locale-sensitive
or lossy float formatting. Unknown fields/versions require an explicit policy.

Digest pipeline: parse → validate → canonicalize → deterministic serialization
→ SHA-256. A pretty-printed JSON document is not itself the canonical digest
input. Test equivalent rational spellings, locale changes, label mapping and
round trips. Serialization is designed here, not implemented or frozen.

