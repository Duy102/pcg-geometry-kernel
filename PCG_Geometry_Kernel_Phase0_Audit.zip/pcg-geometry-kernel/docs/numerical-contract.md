# Numerical contract — selected design, unvalidated backend

Language: C++20. Tier 1 target: Ubuntu 24.04 x86-64 with GCC 13.
Candidate arithmetic: ordinary long double, usable only for proposals and
diagnostics. ABCABC reconstruction itself needs no generic optimizer.
Exact arithmetic: GMP integer/rational types. Certification: an MPFR
directed-rounding interval adapter, including transcendental evaluation.
MPFR/GMP development files are presently unavailable; this design is not an
implemented or validated certification path.

Use documented public headers and library linkage. Do not hand-declare MPFR's
ABI or replace certified evaluation with ordinary libm plus an epsilon.
Pin and record actual backend versions after a successful build, rather than
inventing versions from an untested design.

## Scalar representation

CertifiedScalar contains lower_bound, upper_bound, precision_bits, backend,
backend_version and certification_method. Each endpoint is outward rounded.
Positive iff lower_bound>0; negative iff upper_bound<0. If zero is contained,
the sign is unknown. Zero containment does NOT prove an equality.

Evaluate sin/cos over the entire argument interval, including interior extrema;
endpoint-only evaluation is insufficient. Argument reduction and pi must also
be enclosed rigorously. A chosen MPFR primitive does not by itself validate the
surrounding interval algorithm.

For sinc, return exactly 1 at exact zero. Near zero or across zero, use the
Taylor series sum (-1)^k*x^(2k)/(2k+1)! with a validated remainder bound, or a
validated special-function implementation. For |x|<=1 the alternating-series
remainder at a point is bounded by the next term; interval evaluation must
enclose all x and include that uniform bound. Else divide only if zero is
excluded from the denominator. Tests must cover intervals straddling zero.

## Equality and input semantics

Typed radians retain their exact input representation. Proposed input variants:
exact rational multiples of pi, exact rational radians, and bounded real
intervals. The whole exact rational value is used, not its binary approximation.
Only rational-multiple-of-pi inputs give a simple exact phase-congruence check.
General enclosures cannot certify phase equality merely by shrinking around it.
Use exact symbolic identities where applicable; otherwise INDETERMINATE.
Do not claim that a rational-pi subset is a complete arbitrary-real interface.

## Precision and resources

Proposed escalation: 128 → 256 → 512 → 1024 → 2048 → 4096 bits.
Default per-call time budget: 30 seconds; certificate input cap: 1 MiB;
integer input cap: 4096 bits per numerator/denominator; parser nesting cap: 16.
These are resource limits, not mathematical tolerances. Oversized representation
is a documented InputError; exhausted computation returns INDETERMINATE with
the matching termination reason. Check cancellation and budget between stages
and escalation attempts. Operational limits require implementation tests.

No heuristic epsilon changes a strict inequality into a Boolean fact. Finite
strict systems may use an explicit positive common slack: it exists iff all
finitely many constraints are strictly satisfied, by taking their minimum slack.

